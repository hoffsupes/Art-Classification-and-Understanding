
# Art Classification and understanding

It is reccomended you run this app on firefox. It may be problematic for other browsers! Please install firefox before using this!

The app in bluemix can be found at art-classi-serverjs-tiderode-plumbism.mybluemix.net

PLEASE note that for some reason the app pushed onto cloudfoundry DOES not support the npm opn() function, due to this, a new tab is never opened to display the results. It is a kind request to run the program locally via npm and using mozilla firefox.

Please follow the steps in the command line:

npm install

npm start

Open Mozilla Firefox and go to http://localhost:4527

Copy any image URL and paste it into the box
