
'use strict'        // to use let

var watson = require('watson-developer-cloud');     // watson dev cloud for, needed for visual recognition
var fs = require('fs');
var http = require('http');
const googleIms = require('google-ims');            // google-ims: uses the google custom search engine API to grab image URLs online
let client = googleIms('013190930686577125464:x6nonk9uszm', 'AIzaSyB-OB0cpgQNdp5Ji4kSMiEOrP4hL1nUu0k');


var express = require("express");
var app = express();
var cfenv = require("cfenv");
var bodyParser = require('body-parser')
var popup = require('window-popup').windowPopup;
var opn = require('opn');       // To open a new tab to display the results

var linkurl = "";
var send_text = "";
var imgurls = "";
var context_keys = "";      // string variables initialized


var visual_recognition = watson.visual_recognition({  api_key: 'e28346a91795edd45721a43a6b3715644b2012e8',  version: 'v3',  version_date: '2016-05-20'}); // visual recognition

var PastebinAPI = require('pastebin-js'),    pastebin = new PastebinAPI({'api_dev_key' : '70ef4a8c80b538e636e03202e6a4703f', 'api_user_name' : 'cognitive-man','api_user_password' : 'pastecog'});      // pastebin api

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post("/api/art", function (request, response) {
 
    linkurl = request.body.name;

    response.send("\n Results will display soon, please refresh page to try another image. \n\n Processing ... \n");
    console.log(linkurl);


var params_art = {  "url" : linkurl,  classifier_ids: ["artclassi_1757573310"]}; // art classifier parameter
var params_content = {  classifier_ids: ["default"],  "url": linkurl};      // normal classifier parameter


visual_recognition.classify(params_art, function(err, res) {  // art classification
    if (err)
    {
    console.log(err);
    send_text += " " + "error in classifying using the art classifier:" + err;
    }
    else{
        var lop = [];
    res.images[0].classifiers[0].classes.forEach(function(item,index){
    
        
        if(item.score > 0.9)                    // very high scores (> 0.9) === categories added to context keywords list
        {
            context_keys += " " + item.class;
        }
        
        lop.push(item.score);
        
    })
    console.log(lop);
    var idx = lop.indexOf(Math.max(...lop));
    
    send_text += "\n Original Image_URL: " + params_art.url;
    send_text += " " + ("\n Art Category is: " + res.images[0].classifiers[0].classes[idx].class);          // highest score === assigned category
    
//  context_keys += " " + res.images[0].classifiers[0].classes[idx].class;
    
}

});


visual_recognition.classify(params_content, function(err, res) {  // art understanding
    if (err)
    {
    console.log(err);
    send_text += " " + "error in classifying using the content classifier:" + err;
    }
    else    
    {
    res.images[0].classifiers[0].classes.forEach(function(item,index){
        
        context_keys += " " + item.class;

    })

    console.log("CONTEXT:::" + context_keys);
    
    client.search(context_keys, {page: 2,num: 5 }).then(function (images) {         // search for images from the gathered context keys
    images.forEach(function(i, e, a) {
        
//         console.log(i.url)
           imgurls += i.url + "\n"; 
        
                                    });
});

        
    }
});


visual_recognition.detectFaces (params_content, (err, res) => {                     // face detection in art
  if (err) {
    console.log('error:', err);
    send_text += " " + "error in using the face recognizer:" + err;
    if (typeof callback !== 'undefined' && typeof callback=="function") return callback(err);
  }
  else {
      
      send_text += " " + ("\n Context Keywords : " + context_keys);                 // Accumulating the text to be finally printed in one place
      send_text += " " + ("\n Total faces found: " + res.images[0].faces.length + "\n");    
      
      res.images[0].faces.forEach(function(item,index){  send_text += " " + ("A " + item.gender.gender + " with an approximate age of " + item.age.max + " with an error of " + (100-item.gender.score*100) + "% on the gender and " + (100 - item.age.score*100) + "% on the age. " ); });
      
    if (typeof callback !== 'undefined' && typeof callback=="function") return callback(res);
  }

  imgurls +=  "\nPLEASE GO BACK TO THE PREVIOUS PAGE IF YOU WANT TO PROCESS ANOTHER IMAGE\nIf you dont see any results above you're welcome to do a google image search using ONLY the context keywords. Thank you!";

  
pastebin.createPaste(send_text + "\nSimilar Image URLS (on basis of context keys): \n" + imgurls , "Art Classification and Understanding").then(function (data) {
var lop = opn(data ,{app: 'firefox'}); console.log(data);   }).fail(function (err) {console.log(err);})

});
  
console.log("\nDONE!!\n");

imgurls = "";                       // setting to blank values otherwise retain values on refreshing
send_text = "";
linkurl = "";
context_keys = "";
  });

app.use(express.static(__dirname + '/views'));

var port = process.env.PORT || 4527 // listen on port 4527 for incoming connections
app.listen(port, function() {
    console.log(" SUCCESS! Art Classifier online at : http://localhost:" + port);
});
